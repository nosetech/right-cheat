// ─────────────────────────────────────────────────────────────
// RightCheat — Common Dialog component
// Two patterns: Yes/No (destructive confirm) and OK-only (notice).
// Visual vocabulary matches Mockup v14 (ModalOverlay / DialogFooter /
// FooterButton / DangerButton). Dark + light themes.
// ─────────────────────────────────────────────────────────────

const RC_DARK = {
  isDark: true,
  windowBg: '#0f2236',
  panelBorder: 'rgba(255,255,255,0.10)',
  divider: 'rgba(255,255,255,0.08)',
  textPrimary: 'rgba(255,255,255,0.92)',
  textSecondary: 'rgba(180,210,255,0.65)',
  textMuted: 'rgba(255,255,255,0.25)',
  accentSolid: '#64b4ff',
  appBg: 'linear-gradient(135deg,#0a1929 0%,#0f2236 100%)',
  footerBg: 'rgba(255,255,255,0.018)',
  outerShadow: '0 24px 64px rgba(0,0,0,0.65), 0 0 0 0.5px rgba(255,255,255,0.10)',
};

const RC_LIGHT = {
  isDark: false,
  windowBg: 'linear-gradient(145deg,#eef3fa 0%,#e3ebf6 100%)',
  panelBorder: 'rgba(0,0,0,0.12)',
  divider: 'rgba(0,0,0,0.08)',
  textPrimary: '#1d1d1f',
  textSecondary: '#3a3a4a',
  textMuted: 'rgba(0,0,0,0.30)',
  accentSolid: '#0071e3',
  appBg: 'linear-gradient(135deg,#c8d8ec 0%,#b8cfe8 100%)',
  footerBg: 'rgba(255,255,255,0.40)',
  outerShadow: '0 24px 64px rgba(0,0,50,0.30), 0 0 0 0.5px rgba(255,255,255,0.7)',
};

const RC_FONT_UI = '"Noto Sans JP", -apple-system, BlinkMacSystemFont, sans-serif';

// ── Buttons ──────────────────────────────────────────────────
function FooterButton({ onClick, t, primary, disabled, children }) {
  const [hov, setHov] = React.useState(false);
  const bg = disabled
    ? (t.isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)')
    : primary
      ? (hov ? (t.isDark ? '#7cc0ff' : '#1a82eb') : t.accentSolid)
      : (hov ? (t.isDark ? 'rgba(255,255,255,0.10)' : 'rgba(255,255,255,0.95)')
             : (t.isDark ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.75)'));
  return (
    <button
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        background: bg,
        color: disabled
          ? (t.isDark ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.28)')
          : primary ? '#fff' : t.textPrimary,
        border: `0.5px solid ${primary && !disabled ? 'transparent'
          : (t.isDark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.12)')}`,
        borderRadius: 7, padding: '6px 16px',
        fontFamily: RC_FONT_UI, fontSize: 12.5, fontWeight: 600,
        letterSpacing: '0.01em',
        cursor: disabled ? 'not-allowed' : 'pointer',
        transition: 'all 0.14s', minWidth: 84,
        boxShadow: (!t.isDark && !disabled) ? 'inset 0 1px 0 rgba(255,255,255,0.5)' : 'none',
      }}
    >{children}</button>
  );
}

function DangerButton({ t, onClick, children }) {
  const [hov, setHov] = React.useState(false);
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? '#e85555' : '#ff6b6b',
        color: '#fff',
        border: '0.5px solid transparent',
        borderRadius: 7, padding: '6px 16px',
        fontFamily: RC_FONT_UI, fontSize: 12.5, fontWeight: 600,
        letterSpacing: '0.01em', cursor: 'pointer',
        transition: 'all 0.14s', minWidth: 84,
        boxShadow: hov ? '0 2px 10px rgba(255,80,80,0.30)' : 'none',
      }}>{children}</button>
  );
}

// ── Icon circle (question / confirm glyph) ───────────────────
function DialogIcon({ t, tone }) {
  const danger = tone === 'danger';
  const color = danger ? '#ff6b6b' : t.accentSolid;
  return (
    <div style={{
      width: 40, height: 40, borderRadius: '50%', flexShrink: 0,
      background: danger
        ? (t.isDark ? 'rgba(255,107,107,0.12)' : 'rgba(255,80,80,0.10)')
        : (t.isDark ? 'rgba(100,180,255,0.13)' : 'rgba(0,113,227,0.08)'),
      border: `0.5px solid ${danger ? 'rgba(255,107,107,0.35)'
        : (t.isDark ? 'rgba(100,180,255,0.30)' : 'rgba(0,113,227,0.22)')}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color,
    }}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
        <line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
    </div>
  );
}

// ── The dialog card itself (no overlay; used inside a backdrop) ──
function DialogCard({ t, tone = 'neutral', title, message, footer, width = 384 }) {
  return (
    <div style={{
      width,
      background: t.windowBg,
      border: `0.5px solid ${t.panelBorder}`,
      borderRadius: 14,
      boxShadow: t.outerShadow,
      overflow: 'hidden',
      fontFamily: RC_FONT_UI,
    }}>
      {/* Body */}
      <div style={{ padding: '22px 22px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
          <DialogIcon t={t} tone={tone} />
          <div style={{ flex: 1, minWidth: 0, paddingTop: 1 }}>
            <div style={{
              fontSize: 14.5, fontWeight: 600, color: t.textPrimary,
              marginBottom: 6, lineHeight: 1.4, letterSpacing: '0.01em',
            }}>{title}</div>
            <div style={{
              fontSize: 12.5, lineHeight: 1.65, color: t.textSecondary,
              textWrap: 'pretty',
            }}>{message}</div>
          </div>
        </div>
      </div>
      {/* Footer */}
      <div style={{
        padding: '12px 16px 14px',
        display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 8,
        background: t.footerBg,
        borderTop: `0.5px solid ${t.divider}`,
      }}>{footer}</div>
    </div>
  );
}

// ── Backdrop wrapper — represents the app dimmed behind the dialog ──
function DialogStage({ t, children }) {
  return (
    <div style={{
      position: 'relative', width: '100%', height: '100%',
      background: t.appBg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      overflow: 'hidden',
    }}>
      {/* dim + blur scrim */}
      <div style={{
        position: 'absolute', inset: 0,
        background: t.isDark ? 'rgba(0,0,10,0.45)' : 'rgba(20,30,60,0.28)',
        backdropFilter: 'blur(3px)', WebkitBackdropFilter: 'blur(3px)',
      }} />
      <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
    </div>
  );
}

// ── Localized copy ───────────────────────────────────────────
const RC_COPY = {
  ja: {
    yesno: {
      title: '変更を破棄しますか？',
      message: '編集中のチートシートには保存していない変更があります。破棄すると元に戻すことはできません。',
      no: 'No', yes: 'Yes',
    },
    ok: {
      title: 'ご確認ください',
      message: 'このチートシートは別のウィンドウで開いています。変更内容は最後に保存したウィンドウが優先されます。',
      ok: 'OK',
    },
  },
  en: {
    yesno: {
      title: 'Discard changes?',
      message: 'The cheatsheet you are editing has unsaved changes. Discarding them cannot be undone.',
      no: 'No', yes: 'Yes',
    },
    ok: {
      title: 'Heads up',
      message: 'This cheatsheet is open in another window. Changes from the last saved window take precedence.',
      ok: 'OK',
    },
  },
};

// ── Pattern 1: Yes / No (destructive confirm) ────────────────
function YesNoDialog({ t, lang = 'ja' }) {
  const c = RC_COPY[lang].yesno;
  return (
    <DialogStage t={t}>
      <DialogCard
        t={t}
        tone="danger"
        title={c.title}
        message={c.message}
        footer={
          <React.Fragment>
            <FooterButton t={t}>{c.no}</FooterButton>
            <DangerButton t={t}>{c.yes}</DangerButton>
          </React.Fragment>
        }
      />
    </DialogStage>
  );
}

// ── Pattern 2: OK only (notice) ──────────────────────────────
function OkDialog({ t, lang = 'ja' }) {
  const c = RC_COPY[lang].ok;
  return (
    <DialogStage t={t}>
      <DialogCard
        t={t}
        tone="neutral"
        title={c.title}
        message={c.message}
        footer={<FooterButton t={t} primary>{c.ok}</FooterButton>}
      />
    </DialogStage>
  );
}

Object.assign(window, {
  RC_DARK, RC_LIGHT,
  FooterButton, DangerButton, DialogIcon, DialogCard, DialogStage,
  YesNoDialog, OkDialog,
});
