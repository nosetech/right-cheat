// RightCheat Components — CheatSheet + Preferences screens
// Three visual variants: Glass Dark, Terminal Minimal, Glass Light

// ─────────────────────────────────────────────────────────────
// Shared data
// ─────────────────────────────────────────────────────────────
const SAMPLE_CHEATSHEET_DATA = {
  title: 'Stock IS',
  type: 'command',
  commandlist: [
    { description: '取引履歴', command: 'python -m tool.collect trade list', layout: 'stacked' },
    { description: '現在の損益状況確認', command: 'python -m tool.collect pnl', layout: 'stacked' },
    { description: 'ポートフォリオ分析', command: 'python -m tool.collect portfolio --cash <金額> --report', layout: 'stacked' },
    { description: 'ニュース確認', command: 'python -m tool.collect news --report', layout: 'stacked' },
    {
      description: '月次積立提案プロンプト',
      command: `tool/data/portfolio_report.md の内容をもとに、CLAUDE.md の投資ルールに照らして\n今月の積立資金（30,000円）の使い道を提案してください。\n確認事項:\n- 現在のポートフォリオのルール違反（銘柄比率・現金比率・セクター集中）はあるか\n- 含み損のある銘柄のうち、買い増しに適した銘柄はどれか\n- 直近のニュース・開示情報（portfolio_report.md の末尾に含まれる）に問題はないか\n- 具体的な購入銘柄と株数、購入後の各種比率の変化を示してほしい`,
      layout: 'stacked'
    },
    { description: '新規銘柄スクリーニング', command: 'python -m tool.collect screen --min-div 3.0 --max-pbr 1.0 --report', layout: 'stacked' },
    {
      description: '新規銘柄発掘プロンプト',
      command: `tool/data/screen_report.md のスクリーニング結果と\ntool/data/portfolio_report.md の現在のポートフォリオをもとに、\n 新規投資候補を評価してください。\n確認事項:\n- CLAUDE.md の投資ルール（銘柄数上限・セクター分散・現金比率）を守れるか\n- 帳候銘柄のうち、特に注目すべき銘柄はどれか（理由も含めて）\n- 現在の保有銘柄との業種重複はないか\n- 優待ありの銘柄がある場合は優先的に評価してほしい`,
      layout: 'stacked'
    },
  ]
};

const CHEATSHEET_TITLES = ['Stock IS', 'Git Commands', 'Docker', 'AWS CLI', 'Vim Shortcuts'];

// ─────────────────────────────────────────────────────────────
// Variant A: Glass Dark (Deep blue, liquid glass)
// ─────────────────────────────────────────────────────────────
function CheatSheetGlassDark() {
  const [selected, setSelected] = React.useState('Stock IS');
  const [copied, setCopied] = React.useState(null);
  const [isPinned, setIsPinned] = React.useState(false);
  const [dropdownOpen, setDropdownOpen] = React.useState(false);

  const bg = '#0f2236';
  const panelBg = 'rgba(255,255,255,0.04)';
  const borderColor = 'rgba(255,255,255,0.10)';
  const glassCmd = 'rgba(255,255,255,0.06)';
  const glassCmdHover = 'rgba(255,255,255,0.12)';
  const accentBlue = 'rgba(100,180,255,0.85)';
  const textPrimary = 'rgba(255,255,255,0.92)';
  const textSecondary = 'rgba(180,210,255,0.65)';
  const textMuted = 'rgba(255,255,255,0.25)';
  const font = '"JetBrains Mono", "Fira Code", monospace';
  const fontUI = '"Noto Sans JP", -apple-system, sans-serif';

  const handleCopy = (cmd, idx) => {
    setCopied(idx);
    setTimeout(() => setCopied(null), 900);
  };

  return (
    <div style={{
      width: 360, minHeight: 580,
      background: bg,
      borderRadius: 18,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: fontUI,
      boxShadow: '0 32px 80px rgba(0,0,0,0.6), 0 0 0 0.5px rgba(255,255,255,0.08)',
      position: 'relative',
    }}>
      {/* Overlay title bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        height: 44,
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        background: 'rgba(15,34,54,0.6)',
        borderBottom: `0.5px solid ${borderColor}`,
        display: 'flex', alignItems: 'center',
        padding: '0 16px',
        zIndex: 10,
      }}>
        {/* Traffic lights */}
        <div style={{ display: 'flex', gap: 7, marginRight: 'auto' }}>
          {['#ff736a','#febc2e','#28c840'].map((c,i) => (
            <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', background: c, border: '0.5px solid rgba(0,0,0,0.15)' }} />
          ))}
        </div>
        <span style={{
          position: 'absolute', left: '50%', transform: 'translateX(-50%)',
          fontFamily: fontUI, fontSize: 12, fontWeight: 600,
          color: textSecondary, letterSpacing: '0.02em',
        }}>RightCheat</span>
        <button
          onClick={() => setIsPinned(p => !p)}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            color: isPinned ? accentBlue : textMuted,
            padding: 4, display: 'flex', alignItems: 'center',
            transition: 'color 0.2s',
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/>
          </svg>
        </button>
      </div>

      {/* Content area (below title bar) */}
      <div style={{ paddingTop: 44, flex: 1, overflow: 'auto', padding: '52px 12px 12px' }}>
        {/* CheatSheet selector */}
        <div style={{
          background: panelBg,
          border: `0.5px solid ${borderColor}`,
          borderRadius: 10,
          padding: '4px 8px',
          marginBottom: 10,
          backdropFilter: 'blur(12px)',
        }}>
          <div style={{ fontSize: 10, color: textMuted, fontFamily: font, marginBottom: 2, letterSpacing: '0.08em' }}>CheatSheet</div>
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setDropdownOpen(o => !o)}
              style={{
                width: '100%', background: 'none', border: 'none',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                cursor: 'pointer', padding: '2px 0',
                color: textPrimary, fontFamily: fontUI, fontSize: 13, fontWeight: 500,
              }}
            >
              <span>{selected}</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ opacity: 0.5, transform: dropdownOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </button>
            {dropdownOpen && (
              <div style={{
                position: 'absolute', top: '100%', left: -8, right: -8,
                background: 'rgba(20,45,70,0.97)',
                backdropFilter: 'blur(20px)',
                border: `0.5px solid ${borderColor}`,
                borderRadius: 8, zIndex: 20,
                boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
                marginTop: 4, overflow: 'hidden',
              }}>
                {CHEATSHEET_TITLES.map(t => (
                  <div
                    key={t}
                    onClick={() => { setSelected(t); setDropdownOpen(false); }}
                    style={{
                      padding: '8px 12px',
                      cursor: 'pointer',
                      fontFamily: fontUI, fontSize: 13,
                      color: t === selected ? accentBlue : textPrimary,
                      background: t === selected ? 'rgba(100,180,255,0.08)' : 'none',
                      transition: 'background 0.15s',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.06)'}
                    onMouseLeave={e => e.currentTarget.style.background = t === selected ? 'rgba(100,180,255,0.08)' : 'none'}
                  >
                    {t}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Section label */}
        <div style={{ fontSize: 10, color: textMuted, fontFamily: font, marginBottom: 6, letterSpacing: '0.08em', paddingLeft: 2 }}>確認コマンド</div>

        {/* Command list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
          {SAMPLE_CHEATSHEET_DATA.commandlist.map((item, idx) => (
            <CommandItemDark
              key={idx}
              idx={idx}
              item={item}
              copied={copied === idx}
              onCopy={() => handleCopy(item.command, idx)}
              font={font} fontUI={fontUI}
              textPrimary={textPrimary} textSecondary={textSecondary}
              textMuted={textMuted} accentBlue={accentBlue}
              glassCmd={glassCmd} glassCmdHover={glassCmdHover}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function CommandItemDark({ idx, item, copied, onCopy, font, fontUI, textPrimary, textSecondary, textMuted, accentBlue, glassCmd, glassCmdHover }) {
  const [hovered, setHovered] = React.useState(false);
  const isMultiline = item.command.includes('\n');

  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start' }}>
      <span style={{
        fontFamily: font, fontSize: 10, color: textMuted,
        minWidth: 14, paddingTop: 9, userSelect: 'none', textAlign: 'right',
      }}>{idx + 1}</span>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
        {item.description && (
          <div style={{ fontFamily: fontUI, fontSize: 11, color: textSecondary, paddingLeft: 2, letterSpacing: '0.01em' }}>
            {item.description}
          </div>
        )}
        <div
          onClick={onCopy}
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
          style={{
            background: copied ? 'rgba(100,180,255,0.08)' : hovered ? glassCmdHover : glassCmd,
            border: `0.5px solid ${copied ? 'rgba(100,180,255,0.3)' : hovered ? 'rgba(255,255,255,0.18)' : 'rgba(255,255,255,0.08)'}`,
            borderRadius: 6,
            padding: '5px 8px',
            cursor: 'pointer',
            transition: 'all 0.15s ease',
            display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
            gap: 6,
          }}
        >
          <pre style={{
            fontFamily: font, fontSize: isMultiline ? 10.5 : 12,
            color: copied ? accentBlue : textPrimary,
            margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
            lineHeight: 1.5, flex: 1,
            transition: 'color 0.15s',
          }}>{item.command}</pre>
          <div style={{
            opacity: copied ? 1 : hovered ? 0.6 : 0,
            transition: 'opacity 0.15s',
            color: copied ? accentBlue : 'rgba(255,255,255,0.5)',
            flexShrink: 0, paddingTop: 1,
          }}>
            {copied ? (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            ) : (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
              </svg>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant B: Terminal Minimal (pure terminal aesthetic)
// ─────────────────────────────────────────────────────────────
function CheatSheetTerminal() {
  const [selected, setSelected] = React.useState('Stock IS');
  const [copied, setCopied] = React.useState(null);
  const [isPinned, setIsPinned] = React.useState(false);
  const [dropdownOpen, setDropdownOpen] = React.useState(false);

  const bg = '#0d1117';
  const font = '"JetBrains Mono", "Fira Code", monospace';
  const fontUI = '"Noto Sans JP", monospace';
  const green = '#39d353';
  const dimGreen = 'rgba(57,211,83,0.5)';
  const textPrimary = '#e6edf3';
  const textMuted = '#484f58';
  const borderColor = '#21262d';
  const cmdBg = '#161b22';
  const cmdBgHover = '#1c2128';

  const handleCopy = (cmd, idx) => {
    setCopied(idx);
    setTimeout(() => setCopied(null), 900);
  };

  return (
    <div style={{
      width: 360, minHeight: 580,
      background: bg,
      borderRadius: 10,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: font,
      boxShadow: '0 24px 64px rgba(0,0,0,0.7), 0 0 0 1px #30363d',
      position: 'relative',
    }}>
      {/* Title bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        height: 40,
        background: '#161b22',
        borderBottom: `1px solid ${borderColor}`,
        display: 'flex', alignItems: 'center',
        padding: '0 14px',
        zIndex: 10,
      }}>
        <div style={{ display: 'flex', gap: 7 }}>
          {['#ff736a','#febc2e','#28c840'].map((c,i) => (
            <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', background: c, border: '0.5px solid rgba(0,0,0,0.2)' }} />
          ))}
        </div>
        <span style={{
          position: 'absolute', left: '50%', transform: 'translateX(-50%)',
          fontFamily: font, fontSize: 11, color: textMuted, letterSpacing: '0.05em',
        }}>RightCheat</span>
        <div style={{ marginLeft: 'auto' }}>
          <button
            onClick={() => setIsPinned(p => !p)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: isPinned ? green : textMuted, padding: 2,
              transition: 'color 0.2s',
            }}
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
              <path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Content */}
      <div style={{ paddingTop: 40, flex: 1, overflow: 'auto', padding: '48px 10px 10px' }}>
        {/* Selector */}
        <div style={{
          background: cmdBg,
          border: `1px solid ${borderColor}`,
          borderRadius: 6,
          padding: '5px 8px',
          marginBottom: 10,
          position: 'relative',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ color: green, fontSize: 11 }}>$</span>
            <button
              onClick={() => setDropdownOpen(o => !o)}
              style={{
                flex: 1, background: 'none', border: 'none',
                color: textPrimary, fontFamily: font, fontSize: 12,
                cursor: 'pointer', textAlign: 'left', padding: 0,
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}
            >
              <span>rightcheat --sheet "{selected}"</span>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ opacity: 0.4, transform: dropdownOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </button>
          </div>
          {dropdownOpen && (
            <div style={{
              position: 'absolute', top: '100%', left: 0, right: 0,
              background: '#1c2128',
              border: `1px solid ${borderColor}`,
              borderRadius: 6, zIndex: 20,
              marginTop: 4, overflow: 'hidden',
              boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
            }}>
              {CHEATSHEET_TITLES.map(t => (
                <div
                  key={t}
                  onClick={() => { setSelected(t); setDropdownOpen(false); }}
                  style={{
                    padding: '6px 10px',
                    cursor: 'pointer',
                    fontFamily: font, fontSize: 12,
                    color: t === selected ? green : textPrimary,
                    borderLeft: `2px solid ${t === selected ? green : 'transparent'}`,
                    transition: 'all 0.1s',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = '#2d333b'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'none'; }}
                >
                  {t}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* prompt-style section header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8, paddingLeft: 2 }}>
          <span style={{ color: dimGreen, fontSize: 10, fontFamily: font }}>~/rightcheat</span>
          <span style={{ color: textMuted, fontSize: 10 }}>on</span>
          <span style={{ color: '#79c0ff', fontSize: 10, fontFamily: font }}>main</span>
          <span style={{ color: textMuted, fontSize: 10 }}>❯</span>
          <span style={{ color: textMuted, fontSize: 10, fontFamily: font }}>確認コマンド</span>
        </div>

        {/* Commands */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {SAMPLE_CHEATSHEET_DATA.commandlist.map((item, idx) => (
            <TerminalCommandItem
              key={idx} idx={idx} item={item}
              copied={copied === idx}
              onCopy={() => handleCopy(item.command, idx)}
              font={font} fontUI={fontUI}
              textPrimary={textPrimary} textMuted={textMuted}
              green={green} cmdBg={cmdBg} cmdBgHover={cmdBgHover}
              borderColor={borderColor}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function TerminalCommandItem({ idx, item, copied, onCopy, font, fontUI, textPrimary, textMuted, green, cmdBg, cmdBgHover, borderColor }) {
  const [hovered, setHovered] = React.useState(false);
  const isMultiline = item.command.includes('\n');

  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start' }}>
      <span style={{
        fontFamily: font, fontSize: 9, color: textMuted,
        minWidth: 12, paddingTop: 8, userSelect: 'none', textAlign: 'right',
      }}>{idx + 1}</span>
      <div style={{ flex: 1 }}>
        {item.description && (
          <div style={{
            fontFamily: fontUI, fontSize: 10, color: textMuted,
            paddingLeft: 1, marginBottom: 2, letterSpacing: '0.01em',
          }}>
            # {item.description}
          </div>
        )}
        <div
          onClick={onCopy}
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
          style={{
            background: copied ? 'rgba(57,211,83,0.06)' : hovered ? cmdBgHover : cmdBg,
            border: `1px solid ${copied ? 'rgba(57,211,83,0.25)' : hovered ? '#30363d' : borderColor}`,
            borderRadius: 4,
            padding: '5px 8px',
            cursor: 'pointer',
            transition: 'all 0.12s ease',
            display: 'flex', alignItems: 'flex-start', gap: 6,
          }}
        >
          <span style={{ color: copied ? green : 'rgba(57,211,83,0.45)', fontSize: 11, flexShrink: 0, paddingTop: 1 }}>$</span>
          <pre style={{
            fontFamily: font, fontSize: isMultiline ? 10 : 11.5,
            color: copied ? green : textPrimary,
            margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
            lineHeight: 1.5, flex: 1, transition: 'color 0.12s',
          }}>{item.command}</pre>
          <div style={{
            opacity: copied ? 1 : hovered ? 0.5 : 0,
            transition: 'opacity 0.12s',
            color: copied ? green : textMuted,
            flexShrink: 0, paddingTop: 2,
          }}>
            {copied ? (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            ) : (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
              </svg>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant C: Glass Light (macOS Liquid Glass — light)
// ─────────────────────────────────────────────────────────────
function CheatSheetGlassLight() {
  const [selected, setSelected] = React.useState('Stock IS');
  const [copied, setCopied] = React.useState(null);
  const [isPinned, setIsPinned] = React.useState(false);
  const [dropdownOpen, setDropdownOpen] = React.useState(false);

  const bg = 'linear-gradient(145deg, #e8eef6 0%, #dce5f2 100%)';
  const panelBg = 'rgba(255,255,255,0.55)';
  const borderColor = 'rgba(255,255,255,0.75)';
  const cmdBg = 'rgba(255,255,255,0.45)';
  const cmdBgHover = 'rgba(255,255,255,0.75)';
  const accent = '#0071e3';
  const textPrimary = '#1d1d1f';
  const textSecondary = '#3a3a4a';
  const textMuted = 'rgba(0,0,0,0.3)';
  const font = '"JetBrains Mono", "Fira Code", monospace';
  const fontUI = '"Noto Sans JP", -apple-system, sans-serif';

  const handleCopy = (cmd, idx) => {
    setCopied(idx);
    setTimeout(() => setCopied(null), 900);
  };

  return (
    <div style={{
      width: 360, minHeight: 580,
      background: bg,
      borderRadius: 18,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: fontUI,
      boxShadow: '0 24px 64px rgba(0,0,50,0.12), 0 0 0 0.5px rgba(255,255,255,0.6)',
      position: 'relative',
    }}>
      {/* Overlay title bar — frosted */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        height: 44,
        backdropFilter: 'blur(30px) saturate(200%)',
        WebkitBackdropFilter: 'blur(30px) saturate(200%)',
        background: 'rgba(236,242,252,0.7)',
        borderBottom: '0.5px solid rgba(255,255,255,0.7)',
        display: 'flex', alignItems: 'center',
        padding: '0 16px',
        zIndex: 10,
      }}>
        <div style={{ display: 'flex', gap: 7, marginRight: 'auto' }}>
          {['#ff736a','#febc2e','#28c840'].map((c,i) => (
            <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', background: c, border: '0.5px solid rgba(0,0,0,0.1)' }} />
          ))}
        </div>
        <span style={{
          position: 'absolute', left: '50%', transform: 'translateX(-50%)',
          fontFamily: fontUI, fontSize: 12, fontWeight: 600,
          color: 'rgba(0,0,0,0.55)', letterSpacing: '0.02em',
        }}>RightCheat</span>
        <button
          onClick={() => setIsPinned(p => !p)}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            color: isPinned ? accent : textMuted,
            padding: 4, display: 'flex', alignItems: 'center',
            transition: 'color 0.2s',
          }}
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
            <path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/>
          </svg>
        </button>
      </div>

      {/* Content */}
      <div style={{ paddingTop: 44, flex: 1, overflow: 'auto', padding: '52px 12px 12px' }}>
        {/* Selector — glass pill */}
        <div style={{
          background: panelBg,
          backdropFilter: 'blur(20px) saturate(180%)',
          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
          border: `0.5px solid ${borderColor}`,
          borderRadius: 10,
          padding: '5px 10px',
          marginBottom: 10,
          boxShadow: '0 2px 8px rgba(0,0,50,0.04), inset 0 1px 0 rgba(255,255,255,0.8)',
          position: 'relative',
        }}>
          <div style={{ fontSize: 9, color: textMuted, fontFamily: font, marginBottom: 2, letterSpacing: '0.1em', textTransform: 'uppercase' }}>CheatSheet</div>
          <button
            onClick={() => setDropdownOpen(o => !o)}
            style={{
              width: '100%', background: 'none', border: 'none',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              cursor: 'pointer', padding: 0,
              color: textPrimary, fontFamily: fontUI, fontSize: 13, fontWeight: 500,
            }}
          >
            <span>{selected}</span>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ opacity: 0.35, transform: dropdownOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>
          {dropdownOpen && (
            <div style={{
              position: 'absolute', top: '100%', left: 0, right: 0,
              background: 'rgba(240,245,255,0.92)',
              backdropFilter: 'blur(30px)',
              border: `0.5px solid ${borderColor}`,
              borderRadius: 8, zIndex: 20,
              boxShadow: '0 8px 32px rgba(0,0,50,0.1)',
              marginTop: 4, overflow: 'hidden',
            }}>
              {CHEATSHEET_TITLES.map(t => (
                <div
                  key={t}
                  onClick={() => { setSelected(t); setDropdownOpen(false); }}
                  style={{
                    padding: '7px 12px',
                    cursor: 'pointer',
                    fontFamily: fontUI, fontSize: 13,
                    color: t === selected ? accent : textPrimary,
                    background: t === selected ? 'rgba(0,113,227,0.06)' : 'none',
                    transition: 'background 0.1s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'rgba(0,0,0,0.04)'}
                  onMouseLeave={e => e.currentTarget.style.background = t === selected ? 'rgba(0,113,227,0.06)' : 'none'}
                >
                  {t}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Section label */}
        <div style={{ fontSize: 9, color: textMuted, fontFamily: font, marginBottom: 6, letterSpacing: '0.1em', textTransform: 'uppercase', paddingLeft: 2 }}>確認コマンド</div>

        {/* Command list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
          {SAMPLE_CHEATSHEET_DATA.commandlist.map((item, idx) => (
            <LightCommandItem
              key={idx} idx={idx} item={item}
              copied={copied === idx}
              onCopy={() => handleCopy(item.command, idx)}
              font={font} fontUI={fontUI}
              textPrimary={textPrimary} textSecondary={textSecondary}
              textMuted={textMuted} accent={accent}
              cmdBg={cmdBg} cmdBgHover={cmdBgHover}
              borderColor={borderColor}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function LightCommandItem({ idx, item, copied, onCopy, font, fontUI, textPrimary, textSecondary, textMuted, accent, cmdBg, cmdBgHover, borderColor }) {
  const [hovered, setHovered] = React.useState(false);
  const isMultiline = item.command.includes('\n');

  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start' }}>
      <span style={{
        fontFamily: font, fontSize: 9, color: textMuted,
        minWidth: 12, paddingTop: 9, userSelect: 'none', textAlign: 'right',
      }}>{idx + 1}</span>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
        {item.description && (
          <div style={{ fontFamily: fontUI, fontSize: 11, color: textSecondary, paddingLeft: 2 }}>
            {item.description}
          </div>
        )}
        <div
          onClick={onCopy}
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
          style={{
            background: copied ? 'rgba(0,113,227,0.06)' : hovered ? cmdBgHover : cmdBg,
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
            border: `0.5px solid ${copied ? 'rgba(0,113,227,0.3)' : hovered ? 'rgba(255,255,255,0.9)' : borderColor}`,
            borderRadius: 6,
            padding: '5px 8px',
            cursor: 'pointer',
            transition: 'all 0.15s ease',
            display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
            gap: 6,
            boxShadow: hovered ? '0 2px 8px rgba(0,0,50,0.06), inset 0 1px 0 rgba(255,255,255,0.9)' : 'inset 0 1px 0 rgba(255,255,255,0.6)',
          }}
        >
          <pre style={{
            fontFamily: font, fontSize: isMultiline ? 10.5 : 12,
            color: copied ? accent : textPrimary,
            margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
            lineHeight: 1.5, flex: 1, transition: 'color 0.15s',
          }}>{item.command}</pre>
          <div style={{
            opacity: copied ? 1 : hovered ? 0.5 : 0,
            transition: 'opacity 0.15s',
            color: copied ? accent : textMuted,
            flexShrink: 0, paddingTop: 1,
          }}>
            {copied ? (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            ) : (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
              </svg>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Preferences Screens (matching each variant)
// ─────────────────────────────────────────────────────────────
function PreferencesDark() {
  const [theme, setTheme] = React.useState('DARK');
  const [pinOn, setPinOn] = React.useState(false);
  const font = '"JetBrains Mono", monospace';
  const fontUI = '"Noto Sans JP", -apple-system, sans-serif';
  const bg = '#0f2236';
  const panelBg = 'rgba(255,255,255,0.04)';
  const border = 'rgba(255,255,255,0.10)';
  const textPrimary = 'rgba(255,255,255,0.92)';
  const textSecondary = 'rgba(180,210,255,0.65)';
  const textMuted = 'rgba(255,255,255,0.25)';
  const accent = 'rgba(100,180,255,0.85)';

  return (
    <div style={{
      width: 400, background: bg,
      borderRadius: 18, overflow: 'hidden',
      fontFamily: fontUI,
      boxShadow: '0 32px 80px rgba(0,0,0,0.6), 0 0 0 0.5px rgba(255,255,255,0.08)',
    }}>
      {/* Title bar */}
      <div style={{
        height: 44,
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        background: 'rgba(15,34,54,0.6)',
        borderBottom: `0.5px solid ${border}`,
        display: 'flex', alignItems: 'center', padding: '0 16px',
        position: 'relative',
      }}>
        <div style={{ display: 'flex', gap: 7 }}>
          {['#ff736a','#febc2e','#28c840'].map((c,i) => (
            <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', background: c, border: '0.5px solid rgba(0,0,0,0.15)' }} />
          ))}
        </div>
        <span style={{
          position: 'absolute', left: '50%', transform: 'translateX(-50%)',
          fontFamily: fontUI, fontSize: 12, fontWeight: 600, color: textSecondary,
        }}>Preferences</span>
      </div>

      <div style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 0 }}>
        {/* Section: JSON File */}
        <PrefSectionDark label="CheatSheet Json File" border={border} textSecondary={textSecondary} textMuted={textMuted} font={font} fontUI={fontUI} accent={accent} textPrimary={textPrimary} panelBg={panelBg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: 'rgba(100,180,255,0.12)',
              border: `0.5px solid rgba(100,180,255,0.2)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(100,180,255,0.8)" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
              </svg>
            </div>
            <div style={{
              flex: 1, background: 'rgba(255,255,255,0.06)',
              border: `0.5px solid ${border}`,
              borderRadius: 6, padding: '6px 10px',
            }}>
              <span style={{ fontFamily: font, fontSize: 11, color: textPrimary }}>/Users/hiroyuki/cheatsheet.json</span>
            </div>
            <button style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: textSecondary, padding: 4,
            }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
            </button>
          </div>
        </PrefSectionDark>

        <div style={{ height: 0.5, background: border, margin: '0 -20px' }} />

        {/* Section: Shortcut */}
        <PrefSectionDark label="Global Shortcut" border={border} textSecondary={textSecondary} textMuted={textMuted} font={font} fontUI={fontUI} accent={accent} textPrimary={textPrimary} panelBg={panelBg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontFamily: fontUI, fontSize: 13, fontWeight: 500, color: textPrimary }}>Toggle Visible</span>
            <span style={{ color: textMuted, fontSize: 12 }}>:</span>
            <div style={{
              background: 'rgba(255,255,255,0.06)',
              border: `0.5px solid ${border}`,
              borderRadius: 6, padding: '4px 10px',
              fontFamily: font, fontSize: 12, color: textPrimary,
            }}>^ ⌘ R</div>
            <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: textSecondary, padding: 2 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
              </svg>
            </button>
          </div>
        </PrefSectionDark>

        <div style={{ height: 0.5, background: border, margin: '0 -20px' }} />

        {/* Section: Theme */}
        <PrefSectionDark label="Theme" border={border} textSecondary={textSecondary} textMuted={textMuted} font={font} fontUI={fontUI} accent={accent} textPrimary={textPrimary} panelBg={panelBg}>
          <div style={{ display: 'flex', gap: 0 }}>
            {['LIGHT','DARK','SYSTEM'].map(t => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                style={{
                  background: t === theme ? 'rgba(255,255,255,0.12)' : 'transparent',
                  border: `0.5px solid ${border}`,
                  borderRadius: 0,
                  padding: '5px 14px',
                  cursor: 'pointer',
                  fontFamily: font, fontSize: 11, fontWeight: t === theme ? 700 : 400,
                  color: t === theme ? textPrimary : textMuted,
                  transition: 'all 0.15s',
                  marginLeft: t === 'LIGHT' ? 0 : -0.5,
                  borderRadius: t === 'LIGHT' ? '5px 0 0 5px' : t === 'SYSTEM' ? '0 5px 5px 0' : 0,
                }}
              >{t}</button>
            ))}
          </div>
        </PrefSectionDark>

        <div style={{ height: 0.5, background: border, margin: '0 -20px' }} />

        {/* Section: Other */}
        <PrefSectionDark label="Other Settings" border={border} textSecondary={textSecondary} textMuted={textMuted} font={font} fontUI={fontUI} accent={accent} textPrimary={textPrimary} panelBg={panelBg}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontFamily: fontUI, fontSize: 13, color: textPrimary }}>Visible on all workspaces</span>
            <SwitchDark on={pinOn} onToggle={() => setPinOn(v => !v)} accent={accent} />
          </div>
        </PrefSectionDark>
      </div>
    </div>
  );
}

function PrefSectionDark({ label, children, textSecondary }) {
  return (
    <div style={{ padding: '14px 0' }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: textSecondary, marginBottom: 10, letterSpacing: '0.01em' }}>{label}</div>
      {children}
    </div>
  );
}

function SwitchDark({ on, onToggle, accent }) {
  return (
    <div
      onClick={onToggle}
      style={{
        width: 36, height: 20, borderRadius: 10,
        background: on ? accent : 'rgba(255,255,255,0.15)',
        position: 'relative', cursor: 'pointer',
        transition: 'background 0.2s',
        border: '0.5px solid rgba(255,255,255,0.1)',
      }}
    >
      <div style={{
        width: 16, height: 16, borderRadius: '50%',
        background: '#fff',
        position: 'absolute', top: 2,
        left: on ? 18 : 2,
        transition: 'left 0.2s',
        boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
      }} />
    </div>
  );
}

// Terminal Preferences
function PreferencesTerminal() {
  const [theme, setTheme] = React.useState('DARK');
  const [pinOn, setPinOn] = React.useState(false);
  const font = '"JetBrains Mono", monospace';
  const fontUI = '"Noto Sans JP", monospace';
  const bg = '#0d1117';
  const border = '#21262d';
  const textPrimary = '#e6edf3';
  const textMuted = '#484f58';
  const green = '#39d353';

  return (
    <div style={{
      width: 400, background: bg,
      borderRadius: 10, overflow: 'hidden',
      fontFamily: font,
      boxShadow: '0 24px 64px rgba(0,0,0,0.7), 0 0 0 1px #30363d',
    }}>
      <div style={{
        height: 40,
        background: '#161b22',
        borderBottom: `1px solid ${border}`,
        display: 'flex', alignItems: 'center', padding: '0 14px',
        position: 'relative',
      }}>
        <div style={{ display: 'flex', gap: 7 }}>
          {['#ff736a','#febc2e','#28c840'].map((c,i) => (
            <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', background: c }} />
          ))}
        </div>
        <span style={{
          position: 'absolute', left: '50%', transform: 'translateX(-50%)',
          fontFamily: font, fontSize: 11, color: textMuted,
        }}>Preferences</span>
      </div>

      <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 0 }}>
        {[
          { label: 'CheetSheet Json File', content: (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 32, height: 32, borderRadius: 6, background: '#161b22', border: `1px solid ${border}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={green} strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              </div>
              <div style={{ flex: 1, background: '#161b22', border: `1px solid ${border}`, borderRadius: 4, padding: '5px 8px' }}>
                <span style={{ fontFamily: font, fontSize: 10.5, color: textPrimary }}>/Users/hiroyuki/cheatsheet.json</span>
              </div>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: textMuted, padding: 2 }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
            </div>
          )},
          { label: 'Global Shortcut', content: (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontFamily: fontUI, fontSize: 12, color: textPrimary }}>Toggle Visible</span>
              <span style={{ color: textMuted }}>:</span>
              <div style={{ background: '#161b22', border: `1px solid ${border}`, borderRadius: 4, padding: '3px 8px', fontFamily: font, fontSize: 11, color: textPrimary }}>^ ⌘ R</div>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: textMuted, padding: 2 }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              </button>
            </div>
          )},
          { label: 'Theme', content: (
            <div style={{ display: 'flex', gap: 0 }}>
              {['LIGHT','DARK','SYSTEM'].map(t => (
                <button key={t} onClick={() => setTheme(t)} style={{
                  background: t === theme ? '#161b22' : 'transparent',
                  border: `1px solid ${border}`,
                  borderLeft: t === 'LIGHT' ? `1px solid ${border}` : 'none',
                  padding: '4px 12px', cursor: 'pointer',
                  fontFamily: font, fontSize: 10, fontWeight: t === theme ? 700 : 400,
                  color: t === theme ? green : textMuted,
                  transition: 'all 0.12s',
                  borderRadius: t === 'LIGHT' ? '4px 0 0 4px' : t === 'SYSTEM' ? '0 4px 4px 0' : 0,
                }}>{t}</button>
              ))}
            </div>
          )},
          { label: 'Other Settings', content: (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontFamily: fontUI, fontSize: 12, color: textPrimary }}>Visible on all workspaces</span>
              <SwitchDark on={pinOn} onToggle={() => setPinOn(v => !v)} accent={green} />
            </div>
          )},
        ].map((section, i, arr) => (
          <React.Fragment key={i}>
            <div style={{ padding: '10px 0' }}>
              <div style={{ fontSize: 10, color: textMuted, marginBottom: 8, letterSpacing: '0.05em', fontFamily: font }}>// {section.label}</div>
              {section.content}
            </div>
            {i < arr.length - 1 && <div style={{ height: 1, background: border, margin: '0 -16px' }} />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

// Glass Light Preferences
function PreferencesLight() {
  const [theme, setTheme] = React.useState('LIGHT');
  const [pinOn, setPinOn] = React.useState(false);
  const font = '"JetBrains Mono", "Fira Code", monospace';
  const fontUI = '"Noto Sans JP", -apple-system, sans-serif';
  const bg = 'linear-gradient(145deg, #e8eef6 0%, #dce5f2 100%)';
  const panelBg = 'rgba(255,255,255,0.55)';
  const border = 'rgba(255,255,255,0.7)';
  const textPrimary = '#1d1d1f';
  const textSecondary = '#3a3a4a';
  const textMuted = 'rgba(0,0,0,0.3)';
  const accent = '#0071e3';

  return (
    <div style={{
      width: 400, background: bg,
      borderRadius: 18, overflow: 'hidden',
      fontFamily: fontUI,
      boxShadow: '0 24px 64px rgba(0,0,50,0.12), 0 0 0 0.5px rgba(255,255,255,0.6)',
    }}>
      <div style={{
        height: 44,
        backdropFilter: 'blur(30px) saturate(200%)',
        WebkitBackdropFilter: 'blur(30px) saturate(200%)',
        background: 'rgba(236,242,252,0.7)',
        borderBottom: `0.5px solid ${border}`,
        display: 'flex', alignItems: 'center', padding: '0 16px',
        position: 'relative',
      }}>
        <div style={{ display: 'flex', gap: 7 }}>
          {['#ff736a','#febc2e','#28c840'].map((c,i) => (
            <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', background: c, border: '0.5px solid rgba(0,0,0,0.1)' }} />
          ))}
        </div>
        <span style={{
          position: 'absolute', left: '50%', transform: 'translateX(-50%)',
          fontFamily: fontUI, fontSize: 12, fontWeight: 600, color: 'rgba(0,0,0,0.55)',
        }}>Preferences</span>
      </div>

      <div style={{ padding: '14px 20px', display: 'flex', flexDirection: 'column', gap: 0 }}>
        {[
          { label: 'CheatSheet Json File', content: (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 36, height: 36, borderRadius: 8, background: 'rgba(0,113,227,0.08)', border: '0.5px solid rgba(0,113,227,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={accent} strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              </div>
              <div style={{ flex: 1, background: panelBg, backdropFilter: 'blur(12px)', border: `0.5px solid ${border}`, borderRadius: 7, padding: '6px 10px', boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.8)' }}>
                <span style={{ fontFamily: font, fontSize: 11, color: textPrimary }}>/Users/hiroyuki/cheatsheet.json</span>
              </div>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: textMuted, padding: 4 }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
            </div>
          )},
          { label: 'Global Shortcut', content: (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontFamily: fontUI, fontSize: 13, fontWeight: 500, color: textPrimary }}>Toggle Visible</span>
              <span style={{ color: textMuted, fontSize: 12 }}>:</span>
              <div style={{ background: panelBg, backdropFilter: 'blur(12px)', border: `0.5px solid ${border}`, borderRadius: 6, padding: '4px 10px', fontFamily: font, fontSize: 12, color: textPrimary, boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.8)' }}>^ ⌘ R</div>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: textMuted, padding: 2 }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              </button>
            </div>
          )},
          { label: 'Theme', content: (
            <div style={{ display: 'flex', gap: 0 }}>
              {['LIGHT','DARK','SYSTEM'].map(t => (
                <button key={t} onClick={() => setTheme(t)} style={{
                  background: t === theme ? panelBg : 'rgba(255,255,255,0.2)',
                  backdropFilter: 'blur(12px)',
                  border: `0.5px solid ${border}`,
                  borderLeft: t === 'LIGHT' ? `0.5px solid ${border}` : 'none',
                  padding: '5px 14px', cursor: 'pointer',
                  fontFamily: font, fontSize: 11, fontWeight: t === theme ? 700 : 400,
                  color: t === theme ? accent : textMuted,
                  transition: 'all 0.15s',
                  borderRadius: t === 'LIGHT' ? '5px 0 0 5px' : t === 'SYSTEM' ? '0 5px 5px 0' : 0,
                  boxShadow: t === theme ? 'inset 0 1px 0 rgba(255,255,255,0.8)' : 'none',
                }}>{t}</button>
              ))}
            </div>
          )},
          { label: 'Other Settings', content: (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontFamily: fontUI, fontSize: 13, color: textPrimary }}>Visible on all workspaces</span>
              <SwitchDark on={pinOn} onToggle={() => setPinOn(v => !v)} accent={accent} />
            </div>
          )},
        ].map((section, i, arr) => (
          <React.Fragment key={i}>
            <div style={{ padding: '12px 0' }}>
              <div style={{ fontFamily: fontUI, fontSize: 11, fontWeight: 600, color: 'rgba(0,0,0,0.45)', marginBottom: 10 }}>{section.label}</div>
              {section.content}
            </div>
            {i < arr.length - 1 && <div style={{ height: 0.5, background: 'rgba(0,0,0,0.08)', margin: '0 -20px' }} />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, {
  CheatSheetGlassDark, CheatSheetTerminal, CheatSheetGlassLight,
  PreferencesDark, PreferencesTerminal, PreferencesLight,
  CommandItemDark, TerminalCommandItem, LightCommandItem,
  PrefSectionDark, SwitchDark,
});
